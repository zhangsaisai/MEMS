
#ifndef __MYIIC_M__
#define __MYIIC_M__

#include "MKL25Z4.h"
#include "PE_Types.h"

void IIC_Init_M(void);


#define I2C_READ  1
#define I2C_WRITE 0


#endif
