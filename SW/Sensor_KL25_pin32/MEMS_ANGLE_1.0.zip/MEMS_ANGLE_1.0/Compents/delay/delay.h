/*
 * delay.h
 *
 *  Created on: Jan 14, 2015
 *      Author: lab
 */
#ifndef DELAY_H_
#define DELAY_H_

#include "PE_Types.h"

void TimingDelay_Decrement(void);
void time_delay_us(uint16 nTime);

#endif /* DELAY_H_ */
