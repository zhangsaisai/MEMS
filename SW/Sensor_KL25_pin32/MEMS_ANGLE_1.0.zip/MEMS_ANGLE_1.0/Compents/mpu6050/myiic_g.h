
#ifndef __MYIIC_G__
#define __MYIIC_G__

#include "MKL25Z4.h"
#include "PE_Types.h"

void IIC_Init_G(void);



#endif
